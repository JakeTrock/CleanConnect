export default {
    testing: process.env.testing,
    url: process.env.url,
    mid: process.env.mid,
    pbk: process.env.pbk,
    prk: process.env.prk,
    secretOrKey: process.env.secretOrKey,
    tierID: ["b5rr", "j4xw", "r452"],
    tagCeilings: [1, 10, 100],
    invCeilings: [1, 10, 100],
    akid: process.env.akid,
    ask: process.env.ask,
    bname: process.env.bname,
    domain: process.env.domain,
    email: process.env.email
};